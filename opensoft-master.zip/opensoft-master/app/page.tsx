/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable @typescript-eslint/no-unused-vars */
"use client";

import React, { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Avatar } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import {
  Send,
  Smile,
  Sun,
  Moon,
  Coffee,
  Heart,
  AlertCircle,
  UserIcon,
  ChevronUp,
  ChevronDown,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { baseURL } from "@/lib/helperFunctions";

type MessageType = {
  id: string;
  content: string;
  sender: "bot" | "user" | string;
  timestamp: Date;
};

const quickResponses = [
  { text: "I'm doing great!", icon: <Sun className="mr-2 h-4 w-4" /> },
  { text: "Just okay", icon: <Coffee className="mr-2 h-4 w-4" /> },
  { text: "Feeling down", icon: <Moon className="mr-2 h-4 w-4" /> },
  { text: "Need support", icon: <Heart className="mr-2 h-4 w-4" /> },
];

// Create a global WebSocket instance that persists across renders
let globalWs: WebSocket | null = null;

export default function ChatApp() {
  // State variables
  const [messages, setMessages] = useState<MessageType[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState(true);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [showStats, setShowStats] = useState(true);

  // Stats and animations
  const [streakDays, setStreakDays] = useState(0);
  const [wellnessPoints, setWellnessPoints] = useState(0);
  const [level, setLevel] = useState(0);
  const [levelProgress, setLevelProgress] = useState(0);
  const [showStreakAnimation, setShowStreakAnimation] = useState(false);
  const [showPointsAnimation, setShowPointsAnimation] = useState(false);
  const [showLevelUpAnimation, setShowLevelUpAnimation] = useState(false);
  const [pointsToAdd, setPointsToAdd] = useState(0);

  // User info
  const [userName, setUserName] = useState("");
  const [empId, setEmpId] = useState("");

  // Refs
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const isMountedRef = useRef(false);

  // Fetch chat history
  useEffect(() => {
    const fetchChatHistory = async () => {
      setIsLoadingHistory(true);

      try {
        const token = localStorage.getItem("token");
        if (!token) {
          setConnectionError(
            "Authentication token not found. Please log in again."
          );
          setIsLoadingHistory(false);
          return;
        }

        const response = await fetch(
          `${baseURL}/a/api/v1/emp/details/user/chats`,
          {
            method: "GET",
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
          }
        );

        if (!response.ok) {
          throw new Error(`Failed to fetch chat history: ${response.status}`);
        }

        const data = await response.json();

        if (data.success) {
          const {
            chats,
            name,
            empid,
            lastActive,
            level,
            levelProgress,
            streakDays,
            wellnessPoints,
          } = data.data.userChats;

          // Set user info
          setUserName(name || "");
          setEmpId(empid || "");

          // Set stats
          setLevel(level || 0);
          setLevelProgress(levelProgress || 0);
          setStreakDays(streakDays || 0);
          setWellnessPoints(wellnessPoints || 0);

          // Format chat history to our MessageType format
          const formattedMessages: MessageType[] = [];

          if (chats && Array.isArray(chats)) {
            // Process each chat message
            for (let i = 0; i < chats.length; i++) {
              const chat = chats[i];

              // Skip empty messages
              if (!chat || !chat.message) continue;

              // Convert sender types to our format
              let senderType: "bot" | "user" | string;
              if (chat.sender === "ai") {
                senderType = "bot";
              } else if (chat.sender === "user") {
                senderType = "user";
              } else {
                // Handle other senders (e.g., "Rahul Verma")
                senderType = chat.sender;
              }

              // Try to properly parse JSON messages
              let content = chat.message;
              try {
                // Check if the message is a JSON string (starting with "{")
                if (
                  typeof content === "string" &&
                  content.trim().startsWith("{")
                ) {
                  const parsedJson = JSON.parse(content);
                  if (parsedJson.content) {
                    content = parsedJson.content;
                  } else if (
                    parsedJson.type === "ping" ||
                    parsedJson.type === "presence"
                  ) {
                    // Skip system messages
                    continue;
                  }
                }
              } catch (e) {
                // Not a valid JSON, use original message
              }

              formattedMessages.push({
                id: i.toString(),
                content: content,
                sender: senderType,
                timestamp: new Date(chat.timestamp),
              });
            }
          }

          setMessages(formattedMessages);
        } else {
          throw new Error(data.message || "Failed to fetch chat history");
        }
      } catch (error) {
        console.error("Error fetching chat history:", error);
        setConnectionError(
          "Failed to load chat history. Will try to connect to chat service."
        );
        // Initialize with empty messages if history fails
        setMessages([]);
      } finally {
        setIsLoadingHistory(false);
      }
    };

    fetchChatHistory();
  }, []);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping, isConnected]);

  // One-time WebSocket setup
  useEffect(() => {
    // Only set up WebSocket once after history is loaded
    if (!isLoadingHistory && !isMountedRef.current) {
      isMountedRef.current = true;
      initializeWebSocket();
    }

    return () => {
      // Cleanup on component unmount
      if (globalWs && globalWs.readyState === WebSocket.OPEN) {
        try {
          globalWs.close(1000, "Component unmounted");
        } catch (error) {
          console.error("Error closing WebSocket:", error);
        }
      }
    };
  }, [isLoadingHistory]);

  // Initialize WebSocket connection
  const initializeWebSocket = () => {
    if (globalWs && globalWs.readyState === WebSocket.OPEN) {
      setIsConnected(true);
      return;
    }

    const token = localStorage.getItem("token");
    if (!token) {
      setConnectionError(
        "Authentication token not found. Please log in again."
      );
      return;
    }

    try {
      // Close existing connection if necessary
      if (globalWs) {
        try {
          globalWs.close();
        } catch (e) {
          console.error("Error closing WebSocket:", e);
        }
      }

      // Create new connection
      const wsUrl = `ws://52.66.116.15/c/ws/wsconnect/${token}`;
      globalWs = new WebSocket(wsUrl);

      // Connection opened
      globalWs.onopen = () => {
        setIsConnected(true);
        setConnectionError(null);
      };

      // Connection error
      globalWs.onerror = (error) => {
        console.error("WebSocket error:", error);
        setIsConnected(false);
        setConnectionError("Connection error. Please try again.");
      };

      // Connection closed
      globalWs.onclose = (event) => {
        setIsConnected(false);

        if (event.code !== 1000) {
          setConnectionError(
            "Connection closed. Please try sending a message to reconnect."
          );
        }
      };

      // Message received
      globalWs.onmessage = (event) => {
        try {
          // Skip pong messages
          if (event.data === '{"type":"pong"}') {
            return;
          }

          // Try to parse as JSON
          let data;
          try {
            data = JSON.parse(event.data);
          } catch (parseError) {
            // Handle text messages
            if (
              typeof event.data === "string" &&
              event.data.trim().length > 0
            ) {
              const botMessage: MessageType = {
                id: Date.now().toString(),
                content: event.data,
                sender: "bot",
                timestamp: new Date(),
              };

              setMessages((prevMessages) => [...prevMessages, botMessage]);
              setIsTyping(false);
            }
            return;
          }

          // Handle different message types
          if (data.type === "message") {
            const botMessage: MessageType = {
              id: data.id || Date.now().toString(),
              content: data.content || "Message received with no content",
              sender: "bot",
              timestamp: new Date(),
            };

            setMessages((prevMessages) => [...prevMessages, botMessage]);
            setIsTyping(false);

            // Handle points
            if (data.points) {
              handlePointsUpdate(data.points);
            }
          } else if (data.type === "typing") {
            setIsTyping(true);
          } else if (data.type === "stats_update") {
            // Update stats
            if (data.streakDays !== undefined) {
              setStreakDays(data.streakDays);
              if (data.streakChange > 0) {
                setShowStreakAnimation(true);
                setTimeout(() => setShowStreakAnimation(false), 3000);
              }
            }

            if (data.wellnessPoints !== undefined) {
              const oldLevel = Math.floor(wellnessPoints / 100);
              const newLevel = Math.floor(data.wellnessPoints / 100);

              setWellnessPoints(data.wellnessPoints);

              if (newLevel > oldLevel) {
                setLevel(newLevel);
                setShowLevelUpAnimation(true);
                setTimeout(() => setShowLevelUpAnimation(false), 3000);
              }
            }
          }
        } catch (error) {
          console.error("Error handling WebSocket message:", error);
        }
      };
    } catch (error) {
      console.error("Error creating WebSocket:", error);
      if (error instanceof Error) {
        setConnectionError(`Failed to connect: ${error.message}`);
      } else {
        setConnectionError("Failed to connect: Unknown error");
      }
    }
  };

  // Handle points update
  const handlePointsUpdate = (points: number) => {
    setPointsToAdd(points);
    setShowPointsAnimation(true);

    setTimeout(() => {
      setWellnessPoints((prev) => {
        const newPoints = prev + points;
        const oldLevel = Math.floor(prev / 100);
        const newLevel = Math.floor(newPoints / 100);

        // Check if user leveled up
        if (newLevel > oldLevel) {
          setLevel(newLevel);
          setShowLevelUpAnimation(true);
          setTimeout(() => setShowLevelUpAnimation(false), 3000);
        }

        return newPoints;
      });

      // Hide points animation after delay
      setTimeout(() => setShowPointsAnimation(false), 1000);
    }, 500);
  };

  // Fallback response when WebSocket is unavailable
  const fallbackResponse = () => {
    setIsTyping(true);

    // Generate random points
    const pointsEarned = Math.floor(Math.random() * 15) + 5;
    setTimeout(() => {
      handlePointsUpdate(pointsEarned);
    }, 500);

    // Random streak update
    if (Math.random() > 0.7) {
      setTimeout(() => {
        setStreakDays((prev) => prev + 1);
        setShowStreakAnimation(true);
        setTimeout(() => setShowStreakAnimation(false), 3000);
      }, 2000);
    }

    // Generate bot response
    setTimeout(() => {
      const botResponses = [
        "Thanks for sharing! How else can I support you today?",
        "I appreciate your openness. Would you like to talk more about that?",
        "That's good to know. Remember, it's okay to have all kinds of feelings.",
        "I'm here for you. What would help you feel better right now?",
        "Thank you for checking in today. Is there anything specific on your mind?",
      ];

      const randomResponse =
        botResponses[Math.floor(Math.random() * botResponses.length)];

      const botMessage: MessageType = {
        id: Date.now().toString(),
        content: randomResponse,
        sender: "bot",
        timestamp: new Date(),
      };

      setMessages((prevMessages) => [...prevMessages, botMessage]);
      setIsTyping(false);
    }, 1500);
  };

  // Send message function - simplified to be like Postman
  const handleSendMessage = (content: string) => {
    if (!content.trim()) return;

    // Create user message
    const userMessage: MessageType = {
      id: Date.now().toString(),
      content,
      sender: "user",
      timestamp: new Date(),
    };

    // Add user message to chat
    setMessages((prevMessages) => [...prevMessages, userMessage]);
    setInput("");

    // Award points for user message
    handlePointsUpdate(10);

    // Check WebSocket connection
    if (!isConnected || !globalWs || globalWs.readyState !== WebSocket.OPEN) {
      // Try to reconnect
      initializeWebSocket();

      // Wait brief period for connection to establish
      setTimeout(() => {
        if (globalWs && globalWs.readyState === WebSocket.OPEN) {
          sendSingleMessage(content, userMessage.id);
        } else {
          fallbackResponse();
        }
      }, 1000);
    } else {
      // Send message if connected
      sendSingleMessage(content, userMessage.id);
    }
  };

  // Simple function to send a single message
  const sendSingleMessage = (content: string, messageId: string) => {
    if (!globalWs || globalWs.readyState !== WebSocket.OPEN) {
      fallbackResponse();
      return;
    }

    try {
      // Simple message object - like Postman
      const messageData = {
        type: "message",
        content: content,
        id: messageId,
        timestamp: new Date().toISOString(),
      };

      // Send the message
      // globalWs.send(JSON.stringify(messageData));
      globalWs.send(content);
      setIsTyping(true);
    } catch (error) {
      console.error("Error sending message:", error);
      fallbackResponse();
    }
  };

  // Function to format a timestamp
  const formatTime = (timestamp: Date) => {
    return timestamp.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  // Function to format a date for grouping messages
  const formatDate = (date: Date) => {
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === today.toDateString()) {
      return "Today";
    } else if (date.toDateString() === yesterday.toDateString()) {
      return "Yesterday";
    } else {
      return date.toLocaleDateString("en-US", {
        weekday: "long",
        month: "long",
        day: "numeric",
      });
    }
  };

  // Sort and group messages by date
  const getGroupedAndSortedMessages = () => {
    const groups: Record<string, MessageType[]> = {};

    // Only process if we have messages
    if (messages && messages.length > 0) {
      // Group messages by date
      messages.forEach((message) => {
        if (!message || !message.timestamp) return;

        const date = formatDate(new Date(message.timestamp));
        if (!groups[date]) {
          groups[date] = [];
        }
        groups[date].push(message);
      });
    }

    // Sort dates chronologically with Today and Yesterday at the end
    const getSortValue = (date: string) => {
      if (date === "Today") return 3;
      if (date === "Yesterday") return 2;
      return 1; // Other dates
    };

    // Sort dates with Today last (most recent)
    const sortedDates = Object.keys(groups).sort((a, b) => {
      const aValue = getSortValue(a);
      const bValue = getSortValue(b);

      if (aValue !== bValue) {
        return aValue - bValue; // Sort by special values first
      }

      if (aValue === 1) {
        // Both are regular dates
        return new Date(a).getTime() - new Date(b).getTime();
      }

      return 0;
    });

    return { groups, sortedDates };
  };

  const { groups: groupedMessages, sortedDates } =
    getGroupedAndSortedMessages();

  // Toggle stats display on mobile
  const toggleStats = () => {
    setShowStats(!showStats);
  };

  return !isConnected ? <div className="flex justify-center items-center h-screen">
    <div className="w-12 h-12 border-4 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
  </div>: (
    <main className="flex min-h-screen w-full flex-col items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 p-0 sm:p-2 md:p-4">
      <div className="z-10 flex h-full w-full max-w-4xl items-center justify-center pt-0 sm:pt-8 md:pt-16">
        <Card className="flex h-[100vh] w-full flex-col overflow-hidden rounded-none border border-gray-200 bg-white/70 shadow-lg backdrop-blur-lg sm:h-[95vh] sm:rounded-xl md:h-[90vh]">
          {/* Header area - more compact on mobile */}
          <div className="border-b border-gray-200 bg-white/80 p-2 sm:p-3 md:p-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
              <div className="mb-1.5 sm:mb-0">
                <h1 className="text-lg font-bold text-[#18181B] sm:text-xl md:text-2xl">
                  Mental Wellness Chat
                </h1>
                <p className="text-[11px] text-[#6F7985] sm:text-xs md:text-sm">
                  {userName
                    ? `Hello, ${userName} (${empId})`
                    : "A safe space to check in and share how you're feeling"}
                </p>
              </div>

              {/* Mobile toggle button */}
              <div className="flex items-center justify-between sm:hidden">
                <div className="flex items-center">
                  {connectionError ? (
                    <div className="mr-2 flex items-center text-red-500">
                      <AlertCircle className="mr-1 h-3 w-3" />
                      <span className="text-[10px]">Offline</span>
                    </div>
                  ) : isConnected ? (
                    <div className="mr-2 flex items-center text-green-500">
                      <div className="mr-1 h-1.5 w-1.5 animate-pulse rounded-full bg-green-500" />
                      <span className="text-[10px]">Online</span>
                    </div>
                  ) : (
                    <div className="mr-2 flex items-center text-yellow-500">
                      <div className="mr-1 h-1.5 w-1.5 animate-pulse rounded-full bg-yellow-500" />
                      <span className="text-[10px]">Connecting...</span>
                    </div>
                  )}
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={toggleStats}
                  className="ml-1 p-0.5 h-6 w-6 sm:h-8 sm:w-8"
                >
                  {showStats ? (
                    <ChevronUp className="h-3 w-3 sm:h-4 sm:w-4" />
                  ) : (
                    <ChevronDown className="h-3 w-3 sm:h-4 sm:w-4" />
                  )}
                </Button>
              </div>

              {/* Connection status indicator - Desktop */}
              <div className="hidden sm:block">
                {connectionError ? (
                  <div className="mr-3 sm:mr-4 flex items-center text-red-500">
                    <AlertCircle className="mr-1 h-3 w-3 sm:h-4 sm:w-4" />
                    <span className="text-xs">Offline</span>
                  </div>
                ) : isConnected ? (
                  <div className="mr-3 sm:mr-4 flex items-center text-green-500">
                    <div className="mr-1 h-1.5 w-1.5 sm:h-2 sm:w-2 animate-pulse rounded-full bg-green-500" />
                    <span className="text-xs">Online</span>
                  </div>
                ) : (
                  <div className="mr-3 sm:mr-4 flex items-center text-yellow-500">
                    <div className="mr-1 h-1.5 w-1.5 sm:h-2 sm:w-2 animate-pulse rounded-full bg-yellow-500" />
                    <span className="text-xs">Connecting...</span>
                  </div>
                )}
              </div>
            </div>

            {/* Stats with animations - Collapsible on mobile */}
            <div
              className={`${showStats ? "flex" : "hidden"} mt-1.5 sm:mt-2 flex-wrap items-center justify-center gap-1 sm:gap-2 md:gap-4 sm:flex sm:justify-end`}
            >
              <div className="relative flex items-center gap-1 rounded-full bg-green-100 px-1.5 py-0.5 sm:px-2 sm:py-1 md:px-3">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  className="h-2.5 w-2.5 text-green-600 sm:h-3 sm:w-3 md:h-4 md:w-4"
                >
                  <path d="M2 20h.01M7 20v-4M12 20v-8M17 20v-12M22 20v-16" />
                </svg>
                <span className="text-[10px] font-semibold text-green-800 sm:text-xs">
                  {level}
                  <span className="ml-1 hidden text-[10px] text-green-600 xs:inline sm:text-xs">
                    ({wellnessPoints % 100}/100)
                  </span>
                </span>
                <AnimatePresence>
                  {showLevelUpAnimation && (
                    <motion.div
                      className="absolute -top-5 sm:-top-6 left-0"
                      initial={{ y: 0, opacity: 0 }}
                      animate={{ y: -20, opacity: 1 }}
                      exit={{ y: -40, opacity: 0 }}
                    >
                      <div className="rounded-full bg-green-500 px-1.5 py-0.5 sm:px-2 sm:py-1 text-[10px] sm:text-xs font-bold text-white">
                        Level Up!
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <div className="relative flex items-center gap-1 rounded-full bg-amber-100 px-1.5 py-0.5 sm:px-2 sm:py-1 md:px-3">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  className="h-2.5 w-2.5 text-amber-600 sm:h-3 sm:w-3 md:h-4 md:w-4"
                >
                  <path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z" />
                </svg>
                <span className="text-[10px] font-semibold text-amber-800 sm:text-xs">
                  {streakDays}
                  <span className="hidden xs:inline text-[10px] sm:text-xs">
                    {streakDays !== 1 ? " days" : " day"}
                  </span>
                </span>
                <AnimatePresence>
                  {showStreakAnimation && (
                    <motion.div
                      className="absolute -top-1.5 -right-1.5 sm:-top-2 sm:-right-2"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      exit={{ scale: 0 }}
                    >
                      <div className="rounded-full bg-amber-500 px-1 py-0.5 sm:px-1.5 text-[9px] sm:text-xs font-bold text-white">
                        +1
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <div className="relative flex items-center gap-1 rounded-full bg-purple-100 px-1.5 py-0.5 sm:px-2 sm:py-1 md:px-3">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  className="h-2.5 w-2.5 text-purple-600 sm:h-3 sm:w-3 md:h-4 md:w-4"
                >
                  <circle cx="12" cy="12" r="10" />
                  <path d="M8 14s1.5 2 4 2 4-2 4-2" />
                </svg>
                <span className="text-[10px] font-semibold text-purple-800 sm:text-xs">
                  {wellnessPoints} pts
                </span>
                <AnimatePresence>
                  {showPointsAnimation && (
                    <motion.div
                      className="absolute -top-1.5 -right-1.5 sm:-top-2 sm:-right-2"
                      initial={{ y: 0, opacity: 0, scale: 0.5 }}
                      animate={{ y: -15, opacity: 1, scale: 1 }}
                      exit={{ y: -30, opacity: 0 }}
                      transition={{ duration: 1 }}
                    >
                      <div className="rounded-full bg-purple-500 px-1 py-0.5 sm:px-1.5 text-[9px] sm:text-xs font-bold text-white">
                        +{pointsToAdd}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </div>

          {/* Chat interface */}
          <div className="flex flex-1 flex-col overflow-hidden">
            {connectionError && (
              <div className="bg-red-50 p-1.5 sm:p-2 text-center text-[10px] sm:text-xs md:text-sm text-red-800">
                <AlertCircle className="mr-1 inline h-2.5 w-2.5 sm:h-3 sm:w-3 md:h-4 md:w-4" />
                {connectionError}
              </div>
            )}

            {isLoadingHistory ? (
              <div className="flex flex-1 items-center justify-center">
                <div className="text-center">
                  <div className="inline-block h-5 w-5 sm:h-6 sm:w-6 md:h-8 md:w-8 animate-spin rounded-full border-b-2 border-gray-900"></div>
                  <p className="mt-2 text-[10px] sm:text-xs md:text-sm text-gray-600">
                    Loading your conversation history...
                  </p>
                </div>
              </div>
            ) : (
              <div className="flex-1 space-y-1.5 overflow-y-auto p-2 pt-3 sm:space-y-3 sm:p-3 sm:pt-4 md:space-y-4 md:p-4 md:pt-6">
                {/* Show grouped messages by date */}
                {sortedDates.map((date) => (
                  <div key={date} className="space-y-1.5 sm:space-y-3 md:space-y-4">
                    <div className="sticky top-0 z-10 my-1.5 flex items-center justify-center sm:my-2 md:my-4">
                      <div className="rounded-full bg-gray-200 px-1.5 py-0.5 sm:px-2 sm:py-1 text-[10px] font-medium text-gray-600 sm:text-xs">
                        {date}
                      </div>
                    </div>

                    {groupedMessages[date].map((message) => (
                      <motion.div
                        key={message.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}
                      >
                        {message.sender !== "user" && (
                          <Avatar className="mr-1 flex h-5 w-5 items-center justify-center bg-[#18181B] sm:mr-1.5 sm:h-6 sm:w-6 md:mr-2 md:h-8 md:w-8">
                            {message.sender === "bot" ? (
                              <Smile className="h-3 w-3 text-[#F7FBFD] sm:h-4 sm:w-4 md:h-5 md:w-5" />
                            ) : (
                              <UserIcon className="h-3 w-3 text-[#F7FBFD] sm:h-4 sm:w-4 md:h-5 md:w-5" />
                            )}
                          </Avatar>
                        )}
                        <div
                          className={`max-w-[75%] rounded-lg px-2 py-1 text-xs sm:max-w-[80%] sm:rounded-xl sm:px-3 sm:py-1.5 md:max-w-[85%] md:rounded-2xl md:px-4 md:py-2 md:text-sm ${message.sender === "user"
                            ? "bg-[#18181B] text-[#F7FBFD]"
                            : "bg-[#F4F4F5]"
                            }`}
                        >
                          {message.sender !== "user" &&
                            message.sender !== "bot" && (
                              <p className="mb-0.5 text-[9px] font-medium text-gray-500 sm:mb-1 sm:text-xs">
                                {message.sender}
                              </p>
                            )}
                          <p>{message.content}</p>
                          <p className="mt-0.5 text-[8px] opacity-70 sm:mt-1 sm:text-[10px] md:text-xs">
                            {formatTime(new Date(message.timestamp))}
                          </p>
                        </div>
                        {message.sender === "user" && (
                          <Avatar className="ml-1 flex h-5 w-5 items-center justify-center bg-gray-200 sm:ml-1.5 sm:h-6 sm:w-6 md:ml-2 md:h-8 md:w-8">
                            <div className="text-[8px] font-medium sm:text-[10px] md:text-xs">
                              You
                            </div>
                          </Avatar>
                        )}
                      </motion.div>
                    ))}
                  </div>
                ))}

                {isTyping && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex justify-start"
                  >
                    <Avatar className="mr-1 h-5 w-5 bg-[#18181B] sm:mr-1.5 sm:h-6 sm:w-6 md:mr-2 md:h-8 md:w-8">
                      <Smile className="h-3 w-3 text-[#F7FBFD] sm:h-4 sm:w-4 md:h-5 md:w-5" />
                    </Avatar>
                    <div className="rounded-lg bg-[#F4F4F5] px-2 py-1 sm:rounded-xl sm:px-3 sm:py-1.5 md:rounded-2xl md:px-4 md:py-2">
                      <div className="flex space-x-1">
                        {[0, 150, 300].map((delay) => (
                          <motion.div
                            key={delay}
                            className="h-1 w-1 rounded-full bg-gray-400 sm:h-1.5 sm:w-1.5 md:h-2 md:w-2"
                            animate={{ y: [0, -4, 0] }}
                            transition={{
                              repeat: Infinity,
                              duration: 0.8,
                              delay: delay / 1000,
                            }}
                          />
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}

                <div ref={messagesEndRef} />
              </div>
            )}

            <div className="bg-[#FFFFFF]/50 px-1.5 py-1 backdrop-blur-sm sm:px-3 sm:py-1.5 md:px-4 md:py-2">
              <div className="mb-1 flex flex-wrap gap-1 sm:mb-1.5 sm:gap-1.5 md:mb-2 md:gap-2">
                {quickResponses.map((response, index) => (
                  <motion.div
                    key={index}
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex h-6 items-center bg-white/80 px-1.5 text-[10px] transition-all duration-200 hover:bg-[#F4F4F5] sm:h-7 sm:px-2 sm:text-xs md:h-9 md:px-3 md:text-sm"
                      onClick={() => handleSendMessage(response.text)}
                    >
                      {response.icon && React.cloneElement(response.icon, {
                        className: "mr-1 h-3 w-3 sm:mr-1.5 sm:h-3.5 sm:w-3.5 md:mr-2 md:h-4 md:w-4"
                      })}
                      {response.text}
                    </Button>
                  </motion.div>
                ))}
              </div>

              <div className="border-t border-gray-200 bg-[#FFFFFF]/50 p-1.5 backdrop-blur-sm sm:p-2 md:p-4">
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleSendMessage(input);
                  }}
                  className="flex space-x-1.5 sm:space-x-2"
                >
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Type your message..."
                    className="h-8 flex-1 border-gray-200 bg-white/80 text-xs sm:h-9 sm:text-sm md:h-10"
                    disabled={isLoadingHistory}
                  />
                  <motion.div
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Button
                      type="submit"
                      size="icon"
                      className="h-8 w-8 sm:h-9 sm:w-9 md:h-10 md:w-10"
                      disabled={isLoadingHistory}
                    >
                      <Send className="h-3 w-3 sm:h-3.5 sm:w-3.5 md:h-4 md:w-4" />
                    </Button>
                  </motion.div>
                </form>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Decorative background elements*/}
      <div className="animate-blob fixed top-20 left-10 h-72 w-72 rounded-full bg-purple-200 opacity-30 mix-blend-multiply blur-3xl hidden sm:block" />
      <div className="animate-blob animation-delay-2000 fixed top-40 right-10 h-72 w-72 rounded-full bg-yellow-200 opacity-30 mix-blend-multiply blur-3xl hidden sm:block" />
      <div className="animate-blob animation-delay-4000 fixed bottom-20 left-40 h-72 w-72 rounded-full bg-pink-200 opacity-30 mix-blend-multiply blur-3xl hidden sm:block" />
    </main>
  );
}
